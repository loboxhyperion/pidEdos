<?php
//conexion local 
$db = "idmgov21_pid";
$host = "pid.idm.gov.co";
$pw = "idm-pid2021";
$user = "idmgov21_pid";
/*$db = "epiz_29134950_seguicontratistas";
$host = "sql310.epizy.com";
$pw = "U67KpyS3UF";
$user = "epiz_29134950";*/
//conexion remota
$conexion = mysqli_connect($host,$user,$pw,$db) or die ("No se puede establecer conexion con la DB.")
?>